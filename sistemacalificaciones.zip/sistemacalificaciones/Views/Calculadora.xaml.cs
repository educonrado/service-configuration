using System.Diagnostics;

namespace sistemacalificaciones.Views;

public partial class Calculadora : ContentPage
{
    readonly double factor_seguimiento = 0.3;
    readonly double factor_examen = 0.2;
    public Calculadora()
    {
        InitializeComponent();
    }

    private void Btn_Calcular_Clicked(object sender, EventArgs e)
    {
        
        bool estudiante = Validar_Estudiante(PCK_ESTUDIANTE);
        if (estudiante)
        {
            bool validado = Validar_Campos(Txt_Seguimiento1, Txt_Seguimiento2, Txt_Examen1, Txt_Examen2);
            if (validado)
            {
                double seg_1 = Int32.Parse(Txt_Seguimiento1.Text);
                double seg_2 = Int32.Parse(Txt_Seguimiento2.Text);
                double examen_1 = Int32.Parse(Txt_Examen1.Text);
                double examen_2 = Int32.Parse(Txt_Examen2.Text);
                double nota_1 = Calcular_Nota_Parcial(seg_1, examen_1);
                double nota_2 = Calcular_Nota_Parcial(seg_2, examen_2);
              
                Calcular_Observacion(nota_1,  nota_2);
                //Debug.WriteLine(nota_final);

            }
        }

    }

    private void Calcular_Observacion(double nota_1, double nota_2)
    {
        double nota_final = nota_1 + nota_2;
        string resultado = null;
        switch(nota_final)
        {
            case nota_1 < : resultado = "";
        }
    }

    private double Calcular_Nota_Parcial(double seg, double examen)
    {
        return seg * factor_seguimiento + examen * factor_examen;
    }

    private bool Validar_Estudiante(Picker lista)
    {
        if (lista.SelectedIndex == -1)
        {
            Mostrar_Alerta("Estudiante", "Seleccione un estudiante antes de continuar");
            return false;
        }
        return true;

    }

    private bool Validar_Campos(params Entry[] parametros)
    {
        foreach (var item in parametros)
        {
            if (item == null || string.IsNullOrEmpty(item.Text))
            {
                Mostrar_Alerta("Campos incompletos", $"Ingrese informaci�n v�lida para {item?.Placeholder}");
                return false;
            }
        }
        return true;
    }

    private void Mostrar_Alerta(string titulo, string mensaje, string boton = "Aceptar")
    {
        DisplayAlert(titulo, mensaje, boton);
    }
}