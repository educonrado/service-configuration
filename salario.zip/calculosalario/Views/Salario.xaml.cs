
namespace calculosalario.Views;

public partial class Salario : ContentPage

{
    readonly double Tasa_Iess = 9.45;
    public Salario()

    {
        InitializeComponent();
        this.lblPorcentaje.Text = $"El aporte como empleado corresponde a: {Tasa_Iess.ToString()}%.";
    }

    private void Calcular_Clicked(object sender, EventArgs e)
    {
        if (Validar_Campos(TxtNombre, TxtApellido, TxtEdad, TxtSalario))
        {
            try
            {
                string nombre = TxtNombre.Text;
                string apellido = TxtApellido.Text;
                int edad = Int32.Parse(TxtEdad.Text);
                double salario = double.Parse(TxtSalario.Text);
                double Aporte_Iess = Math.Round(salario * Tasa_Iess / 100, 2);
                
                DisplayAlert("Aporte IESS", $"Bienvenido {nombre} {apellido}\n" +
                    $"Tienes {edad} a�os\n" +
                    $"Tu aporte mensual es: ${Aporte_Iess.ToString()}",
                    "Aceptar");
            }
            catch (FormatException ex){
                Console.WriteLine(ex.ToString());
                DisplayAlert("Error", $"Error en los campos ingresados: {ex.Message}", "Aceptar");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
                DisplayAlert("Error", $"Ocurri� un error inesperado: {ex.Message}", "Aceptar");
               
            }
             Limpiar_Campos();
        }
    }

    private void Limpiar_Campos()
    {
        TxtNombre.Text = null;
        TxtApellido.Text = null;
        TxtEdad.Text = null;
        TxtSalario.Text = null;
        TxtNombre.Focus();
    }

    private bool Validar_Campos(params Entry[] parametros)
    {
        foreach (var item in parametros)
        {
            if (item == null || string.IsNullOrEmpty(item.Text))
            {
                DisplayAlert("Error", $"Ingrese informaci�n v�lida para {item?.Placeholder}", "Aceptar");
                return false;
            }
        }
        return true;
    }
}