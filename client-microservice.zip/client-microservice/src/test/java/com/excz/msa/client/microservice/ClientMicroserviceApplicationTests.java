package com.excz.msa.client.microservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
