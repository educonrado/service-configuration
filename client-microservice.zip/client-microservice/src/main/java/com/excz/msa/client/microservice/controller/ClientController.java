package com.excz.msa.client.microservice.controller;

import com.excz.msa.client.microservice.entity.ClientEntity;
import com.excz.msa.client.microservice.repository.ClientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/clients")
public class ClientController {

    @Autowired
    private ClientRepository clientRepository;

    @GetMapping
    public List<ClientEntity> getAllClients() {
        return clientRepository.findAll();
    }

    @PostMapping
    public ClientEntity createClient(@RequestBody ClientEntity client){
        return clientRepository.save(client);
    }

    @DeleteMapping(params = "/{id}")
    public void deleteClient(@PathVariable Integer id){
        clientRepository.deleteById(id);
    }

    @PutMapping
    public ClientEntity updateClient(@RequestBody ClientEntity client){
        return clientRepository.save(client);
    }
}
